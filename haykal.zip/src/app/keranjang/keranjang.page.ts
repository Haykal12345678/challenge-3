import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-keranjang',
  templateUrl: './keranjang.page.html',
  styleUrls: ['./keranjang.page.scss'],
})
export class KeranjangPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
