import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detailartikel',
  templateUrl: './detailartikel.page.html',
  styleUrls: ['./detailartikel.page.scss'],
})
export class DetailartikelPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
