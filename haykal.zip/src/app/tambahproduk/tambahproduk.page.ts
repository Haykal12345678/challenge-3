import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tambahproduk',
  templateUrl: './tambahproduk.page.html',
  styleUrls: ['./tambahproduk.page.scss'],
})
export class TambahprodukPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
